<?php $__env->startSection('title', 'Új címke'); ?>

<?php $__env->startSection('content'); ?>

    <h1 class="ps-3">Új címke</h1>
        <hr />
        <form method="post" action="
        <?php if(isset($label)): ?>
            <?php echo e(route('change', ['id' => $label->id])); ?>">
        <?php else: ?>
            <?php echo e(route('newlabel')); ?>">
        <?php endif; ?>
            <?php echo csrf_field(); ?>
            <?php if(isset($label)): ?>
                <?php echo method_field('put'); ?>
                <div class="mb-3">
                    <p>Név:</p>
                    <input type="text" id="name" name="name" max="30" placeholder="<?php echo e($label->name); ?>">
                </div>
                <div class="mb-3">
                    <p>Látható?</p>
                    <input type="checkbox" id="display" name="display" value="Yes"
                    <?php if($label->display): ?>
                        checked
                    <?php endif; ?>>
                </div>
                <div class="row">
                    <p>Szín:</p>
                    <input type="text" id="color" name="color" size="10" maxlength="10" width="1" placeholder="<?php echo e($label->color); ?>">
                </div>
                <div class="row">
                    <button type="submit" class="btn btn-primary">Mentés</button>
                </div>

            <?php else: ?>
                <div class="mb-3">
                    <p>Név:</p>
                    <input type="text" id="name" name="name" max="30">
                </div>
                <div class="mb-3">
                    <p>Látható?</p>
                    <input type="checkbox" id="display" name="display" value="Yes" />
                </div>
                <div class="row">
                    <p>Szín:</p>
                    <input type="text" id="color" name="color" size="10" maxlength="10" width="1">
                </div>
                <div class="row">
                    <button type="submit" class="btn btn-primary">Mentés</button>
                </div>
            <?php endif; ?>
        </form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Aaa_Suli\Szerveroldali\Laravel_bead\muzeum\resources\views/site/label_form.blade.php ENDPATH**/ ?>