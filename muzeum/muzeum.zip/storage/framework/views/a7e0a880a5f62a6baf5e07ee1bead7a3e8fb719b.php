<?php $__env->startSection('title', 'Címke módosítása'); ?>

<?php $__env->startSection('content'); ?>

<?php $__currentLoopData = $labels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <span style="background-color:<?php echo e($label->color); ?>;">
        <?php echo e($label->name); ?>

    </span>
    <a href="<?php echo e(route('listItems', ['id' => $label->id])); ?>">Listáz</a>
    <a href="<?php echo e(route('changeItems', ['id' => $label->id])); ?>">Módosít</a>
    <a href="">Töröl</a>
    <br>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Aaa_Suli\Szerveroldali\Laravel_bead\muzeum\resources\views/site/label_modify.blade.php ENDPATH**/ ?>