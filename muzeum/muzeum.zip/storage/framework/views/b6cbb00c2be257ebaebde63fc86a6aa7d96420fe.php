<?php $__env->startSection('title', 'Open Items'); ?>

<?php $__env->startSection('content'); ?>
    <h1 class="ps-3">Kiállított tárgyak</h1>
    <hr />
    <div class="table-responsive">
        <table class="table align-middle table-hover">
            <thead class="text-center table-light">
                <tr>
                    <th style="width: 10%">Név</th>
                    <th style="width: 50%">Leírás</th>
                    <th style="width: 30%">Kép</th>
                    <th style="width: 10%">Gomb</th>
                </tr>
            </thead>
            <tbody class="text-center">
                <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="table-danger">
                        <td>
                            <a href="<?php echo e(route('items.show', ['item' => $item->id])); ?>"><?php echo e($item->name); ?></a>
                        </td>
                        <td>
                            <p><?php echo e($item->description); ?></p>
                        </td>
                        <td>
                            <img src="<?php echo e($item->image); ?>" alt="" width="50%" height="50%">
                        </td>
                        <td>
                            <a class="btn btn-outline-secondary" href="<?php echo e(route('items.show', ['item' => $item->id])); ?>">
                                <i class="fa-solid fa-angles-right fa-fw"></i>
                            </a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Aaa_Suli\Szerveroldali\Laravel_bead\muzeum\resources\views/site/items.blade.php ENDPATH**/ ?>