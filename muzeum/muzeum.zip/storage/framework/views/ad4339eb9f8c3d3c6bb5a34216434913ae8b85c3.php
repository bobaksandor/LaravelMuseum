<?php $__env->startSection('title', $item->name); ?>

<?php $__env->startSection('content'); ?>

    <div class="d-flex">
        <h1 class="ps-3 me-auto"><?php echo e($item->name); ?> </h1>
        <p>Megszerezve: <?php echo e($item->obtained); ?></p>
        
    </div>
    <div class="table-responsive">
        <table class="table align-middle table-hover">
            <thead class="text-center table-light">
                <tr>
                    <th style="width: 50%">Leírás</th>
                    <th style="width: 50%">Kép</th>
                </tr>
            </thead>
            <tbody class="text-center">
                <tr>
                    <td><?php echo e($item->description); ?></td>
                    <td><img src="<?php echo e($item->image); ?>" alt=""  width="10%" height="10%"></td>
                </tr>
            </tbody>

        </table>
    </div>
        <?php $__currentLoopData = $item->labels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($label->display == True): ?>
                <span style="background-color:<?php echo e($label->color); ?>;">
                    <?php echo e($label->name); ?>

                </span>
                <br>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <div>

    </div>

    <hr />
    <?php $__currentLoopData = $item->comments->sortByDesc('created_at'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="card mb-3">
                <div class="card-header d-flex">
                    <div class="me-auto"><span class="badge bg-secondary">#<?php echo e($loop->index); ?></span> | <strong><?php echo e($comment->user->name); ?></strong> | <?php echo e($comment->created_at); ?></div>
                    <?php if($item->comments->count() == 0): ?>
                        <p>Még nincs hozzászólás</p>
                    <?php endif; ?>
                </div>
                <div class="card-body">
                    <?php echo e($comment->text); ?>

                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <hr>
    <h2>Új hozzászólás írása</h2>
    <form>
        <div class="mb-3">
            <textarea class="form-control" name="text" id="text" cols="30" rows="10" placeholder="Hozzászólás..."></textarea>
        </div>
        <div class="mb-3">
            <input type="file" class="form-control" id="file">
        </div>
        <div class="row">
            <button type="submit" class="btn btn-primary">Küldés</button>
        </div>
    </form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Aaa_Suli\Szerveroldali\Laravel_bead\muzeum\resources\views/site/item.blade.php ENDPATH**/ ?>